// Copyright 2017 Oath, Inc.
// Licensed under the terms of the Apache version 2.0 license. See LICENSE file for terms.

// Package zms contains a client library to talk to Athenz ZMS.
package zms
