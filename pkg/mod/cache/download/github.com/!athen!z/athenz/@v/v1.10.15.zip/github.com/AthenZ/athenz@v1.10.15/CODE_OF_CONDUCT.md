## Athenz Community Code of Conduct

Athenz follows the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/master/code-of-conduct.md).
