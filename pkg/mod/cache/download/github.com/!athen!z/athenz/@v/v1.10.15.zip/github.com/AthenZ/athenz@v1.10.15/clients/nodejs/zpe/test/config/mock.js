'use strict';

var mock = require('mock-require');
var crypto = require('crypto');
var fs = require('fs');

mock('../../src/', {});
