# Athenz Setup on AWS

Athenz Team provides a set of instructions using CloudFormation Templates to deploy
Athenz ZMS, ZTS and UI components on Linux EC2 instances in AWS.

https://github.com/AthenZ/athenz-aws-cf-setup/blob/master/README.md