Athenz Jetty Container
=======================

This is Athenz Jetty Container - it starts Jetty in embedded mode and loads the
servlets available in its webapps directory - which could be either ZMS or ZTS
servlets.

## License

Copyright 2017 Yahoo Inc.

Licensed under the [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0)
