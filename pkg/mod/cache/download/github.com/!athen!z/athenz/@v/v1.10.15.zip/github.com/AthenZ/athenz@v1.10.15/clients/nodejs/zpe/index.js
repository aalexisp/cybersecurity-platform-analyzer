'use strict';
let AuthZPEClient = require('./src/AuthZPEClient');
AuthZPEClient.AccessCheckStatus = require('./src/AccessCheckStatus');
module.exports = AuthZPEClient;
