<a id="markdown-using-public-oauth2-identity-provider" name="using-public-oauth2-identity-provider"></a>
# Using public OAuth2 Identity Provider

<!-- TOC -->

- [Using public OAuth2 Identity Provider](#using-public-oauth2-identity-provider)
    - [Example](#example)

<!-- /TOC -->

<a id="markdown-example" name="example"></a>
## Example

- [Auth0](./IdP/Auth0.md)
