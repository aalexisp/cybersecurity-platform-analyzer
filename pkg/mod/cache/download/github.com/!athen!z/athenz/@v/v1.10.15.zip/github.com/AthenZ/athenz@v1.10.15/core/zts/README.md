ZTS Core Support
================

Contains the ZTS interface and support classes.

The interface, schema, and support classes are generated from the ZTS RDL definitions herein. Clients and servers will use these classes to implement the interface.

## License

Copyright 2016 Yahoo Inc.

Licensed under the [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0)
