// Stub to satisfy go 1.6 complaint about no buildable source files
//
// Future documentation placeholder
package codegen
