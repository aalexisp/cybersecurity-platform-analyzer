# Percent

Package percent escapes strings using [percent-encoding](https://en.wikipedia.org/wiki/Percent-encoding)

[Docs](https://pkg.go.dev/github.com/mtibben/percent?tab=doc)
