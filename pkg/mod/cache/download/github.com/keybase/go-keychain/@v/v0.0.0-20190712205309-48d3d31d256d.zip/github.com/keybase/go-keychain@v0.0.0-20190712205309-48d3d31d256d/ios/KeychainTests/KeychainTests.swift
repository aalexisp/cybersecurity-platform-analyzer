//
//  KeychainTests.swift
//  KeychainTests
//
//  Created by Gabriel on 9/25/15.
//  Copyright © 2015 Gabriel Handford. All rights reserved.
//

import XCTest
@testable import Keychain

// Tests don't work with bind framework for some reason.
// Using the app.
class KeychainTests: XCTestCase {

}
