// +build complex_tests

package tags_tests_test

import (
	. "github.com/onsi/ginkgo"
)

var _ = Describe("Ignored", func() {
	It("should not have these tests", func() {

	})

	It("should not have these tests", func() {

	})
})
